tinymce.init({
    selector: "#mytextarea",
    width: 900,
    height: 600,
    toolbar: "forecolor backcolor",
    color_cols: "5"
});